// Handle Login
document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault();  // Prevent form submission

  // Get username and password
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  // Hardcoded login credentials
  if (username === 'Cheat' && password === '123') {
    // Hide login page, show main app page
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('mainAppPage').style.display = 'block';

    // Show welcome message
    alert('Welcome to KAZI x CHEATS');
  } else {
    // Show error message
    document.getElementById('loginMessage').textContent = 'Invalid username or password';
  }
});

// Function to activate Aimbot (simulating the "Inject" button)
function activateAimbot() {
  // Simulating loading time
  setTimeout(function() {
    // Change the status to "Activated"
    document.getElementById('status').textContent = 'Status: Cheat Activated';
  }, 2000); // 2 seconds delay
}

// Function to select Headshot v1 or v2
function selectHeadshot(version) {
  alert(`Headshot ${version} activated`);
  // You can add further logic based on the version selected
}

// Function to activate Sniper Hack
function activateSniperHack() {
  alert('Sniper Hack Activated');
  // You can add further logic for Sniper Hack here
}

// Function to update memory option
document.getElementById('memorySelect').addEventListener('change', function() {
  const selectedMemory = this.value;
  console.log(`Memory selected: ${selectedMemory}`);
});

// Function to update update option
document.getElementById('updateSelect').addEventListener('change', function() {
  const selectedUpdate = this.value;
  console.log(`Update selected: ${selectedUpdate}`);
});
